import { Game } from "pages/GameListPage/GameListPage";
import React from "react";
import AddToBasketButton from "./components/AddToBasketButton/AddToBasketButton";
import GameTitle from "./components/GameTitle/GameTitle";
import Price from "./components/Price/Price";
import Quantity from "./components/Quantity/Quantity";
import Rating from "./components/Rating/Rating";
import Tags from "./components/Tags/Tags";
import "./styles.css";

type GameDetailsCardProps = { game: Game };

const GameDetailsCard = ({
  game: { name, artworkUrl, releaseDate, rating, tags, price },
}: GameDetailsCardProps) => {
  const [quantity, setQuantity] = React.useState(1);

  return (
    <div className="GameDetailsCard">
      <GameTitle
        name={name}
        releaseDate={releaseDate}
        artworkUrl={artworkUrl}
      />
      <Rating value={rating} />
      <Tags tags={tags} />
      <Quantity value={quantity} onChange={setQuantity} />
      <Price value={price} />
      <AddToBasketButton isAdded={false} onClick={console.log} />
    </div>
  );
};

export default GameDetailsCard;
