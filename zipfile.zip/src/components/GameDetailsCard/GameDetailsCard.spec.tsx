import { fireEvent, render } from "@testing-library/react";
import GameDetailsCard from "./GameDetailsCard";
import React from "react";

describe("GameDetailsCard", () => {
  it("Should have a working quantity increase button", () => {
    // Arrange
    const game = {
      id: "1152350815",
      artworkUrl:
        "https://is5-ssl.mzstatic.com/image/thumb/Purple124/v4/f8/b5/fe/f8b5fead-500d-59ed-25e0-dca91d6aba1c/AppIcon-0-1x_U007emarketing-0-0-GLES2_U002c0-512MB-sRGB-0-0-0-85-220-0-0-0-6.png/200x200bb.png",
      name: "FINALFANTASY XV POCKET EDITION",
      rating: 4,
      tags: ["Games", "Action", "Role Playing"],
      releaseDate: "2018-02-08",
      price: 2.1,
    };
    const { getByTestId } = render(<GameDetailsCard game={game} />);

    // Act
    fireEvent.click(getByTestId("button-increase"));

    // Assert
    expect(getByTestId("quantity")).toHaveTextContent("2");
  });

  it("Should not decrease quantity past 1", () => {
    // Arrange
    const game = {
      id: "1152350815",
      artworkUrl:
        "https://is5-ssl.mzstatic.com/image/thumb/Purple124/v4/f8/b5/fe/f8b5fead-500d-59ed-25e0-dca91d6aba1c/AppIcon-0-1x_U007emarketing-0-0-GLES2_U002c0-512MB-sRGB-0-0-0-85-220-0-0-0-6.png/200x200bb.png",
      name: "FINALFANTASY XV POCKET EDITION",
      rating: 4,
      tags: ["Games", "Action", "Role Playing"],
      releaseDate: "2018-02-08",
      price: 2.1,
    };
    const { getByTestId } = render(<GameDetailsCard game={game} />);

    // Act
    fireEvent.click(getByTestId("button-decrease"));

    // Assert
    expect(getByTestId("quantity")).toHaveTextContent("1");
  });
});
