import React from "react";
import "./styles.css";

const Price = (props: { value: number }) => {
  return <p className="Price">{props.value}</p>;
};

export default Price;
