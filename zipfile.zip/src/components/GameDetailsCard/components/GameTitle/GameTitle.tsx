import React from "react";
import "./styles.css";

type GameTitleProps = {
  name: string;
  releaseDate: string;
  artworkUrl: string;
};

const GameTitle = ({ name, releaseDate, artworkUrl }: GameTitleProps) => {
  return (
    <div className="GameTitle">
      <img src={artworkUrl} alt={name} />
      <div className="GameTitle__Info">
        <p className="GameTitle__Label">Released ∙ {releaseDate}</p>
        <p className="GameTitle__Name">{name}</p>
      </div>
    </div>
  );
};

export default GameTitle;
