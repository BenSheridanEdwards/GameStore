import React, { useCallback } from "react";
import Button from "components/Button/Button";
import { ReactComponent as AddIcon } from "assets/icons/add.svg";
import { ReactComponent as SubtractIcon } from "assets/icons/subtract.svg";
import "./styles.css";

type QuantityProps = {
  value: number;
  onChange: (newValue: number) => void;
};

const Quantity = ({ value, onChange }: QuantityProps) => {
  const handleDecreaseClick = useCallback(() => {
    if (value > 1) {
      onChange(value - 1);
    }
  }, [onChange, value]);

  const handleIncreaseClick = useCallback(() => {
    onChange(value + 1);
  }, [onChange, value]);

  return (
    <div className="Quantity">
      <div className="Quantity__label">Quantity</div>
      <div className="Quantity__counter">
        <Button
          onClick={handleDecreaseClick}
          variant="link"
          testId="button-decrease"
        >
          <SubtractIcon color="#303550" />
        </Button>

        <div data-testid="quantity">{value}</div>

        <Button
          onClick={handleIncreaseClick}
          variant="link"
          testId="button-increase"
        >
          <AddIcon color="#303550" />
        </Button>
      </div>
    </div>
  );
};

export default Quantity;
