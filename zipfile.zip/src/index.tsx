import ReactDOM from "react-dom";
import React, { Dispatch, useReducer } from "react";
import GameListPage from "./pages/GameListPage/GameListPage";
import CheckoutPage from "./pages/CheckoutPage/CheckoutPage";
import "fontsource-roboto";
import "./mock/server";
import "./index.css";

import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
} from "react-router-dom";

type CartItem = {
  id: string;
  quantity: number;
};

const initialCart: CartItem[] = [];

enum ActionType {
  ADD = "add",
  REMOVE = "remove",
}

type CartAction = { type: ActionType; payload: CartItem };

function cartReducer(state: CartItem[], action: CartAction) {
  switch (action.type) {
    case ActionType.ADD:
      return state.concat(action.payload);
    case ActionType.REMOVE:
      return state.filter((item) => item.id !== action.payload.id);
    default:
      throw new Error("unknown action");
  }
}

const CartContext = React.createContext<{
  cart: CartItem[];
  dispatch: Dispatch<CartAction>;
}>({
  cart: [],
  dispatch: () => {},
});

const App = () => {
  const [cart, dispatch] = useReducer(cartReducer, initialCart);

  return (
    <React.StrictMode>
      <CartContext.Provider value={{ cart, dispatch }}>
        <Router>
          <Switch>
            <Route path="/list">
              <GameListPage />
            </Route>

            <Route path="/checkout">
              <CheckoutPage />
            </Route>

            <Redirect from="*" to="/list" />
          </Switch>
        </Router>
      </CartContext.Provider>
    </React.StrictMode>
  );
};

ReactDOM.render(<App />, document.getElementById("root"));
