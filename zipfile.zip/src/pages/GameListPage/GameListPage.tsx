import GameDetailsCard from "components/GameDetailsCard/GameDetailsCard";
import React, { memo, useEffect, useState } from "react";
import Layout from "../../components/Layout/Layout";
import "./styles.css";

export type Game = {
  id: string;
  artworkUrl: string;
  name: string;
  rating: number;
  tags: string[];
  releaseDate: string;
  price: number;
};

const GameListPage = memo(() => {
  const [games, setGames] = useState([]);

  useEffect(() => {
    fetch("/api/games")
      .then((response) => response.json())
      .then((data) => setGames(data.games));
  }, []);

  return (
    <Layout title="Games">
      <div className="GameListPage__List">
        {games.map((game: Game) => (
          <GameDetailsCard key={game.id} game={game} />
        ))}
      </div>
    </Layout>
  );
});

export default GameListPage;
