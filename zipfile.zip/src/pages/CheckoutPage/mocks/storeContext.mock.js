export const storeContextValueMock = {
  storeGames: [
    {
      id: "1",
      artworkUrl: "",
      title: "Game 1",
      price: 1.5,
      rating: 5,
      releaseDate: "2011-10-01",
      tags: ["Shooter"],
      inBasket: true,
      quantity: 2,
    },
  ],
  basket: [
    {
      id: "1",
      artworkUrl: "",
      title: "Game 2",
      price: 1.5,
      rating: 5,
      releaseDate: "2011-10-01",
      tags: ["Shooter"],
      inBasket: true,
      quantity: 2,
    },
  ],
};
